import express from "express";
import dotenv from "dotenv";
import { MongoClient } from "mongodb";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";

dotenv.config();

const app = express();
app.use(express.json());

const client = new MongoClient(process.env.MONGO_URI);
await client.connect();
const db = client.db(process.env.MONGO_DB);

// ----------------------------
// MCP Server (for AI integration)
// ----------------------------
const mcp = new McpServer({
    name: "mongo-mcp-server",
    version: "1.0.0",
});

// Helper to validate collection
const validateCollection = (collection) => {
    if (!collection || typeof collection !== 'string' || collection.trim() === '') {
        throw new Error("Collection name is required and cannot be empty.");
    }
    return collection.trim();
};

// Query
mcp.tool("queryDocuments", async ({ collection, filter = {} }) => {
    const colName = validateCollection(collection);
    return await db.collection(colName).find(filter).toArray();
});

// Insert
mcp.tool("insertDocument", async ({ collection, document }) => {
    const colName = validateCollection(collection);
    const result = await db.collection(colName).insertOne(document);
    return { insertedId: result.insertedId };
});

// Update
mcp.tool("updateDocument", async ({ collection, filter, update }) => {
    const colName = validateCollection(collection);
    const result = await db.collection(colName).updateMany(filter, update);
    return { matched: result.matchedCount, modified: result.modifiedCount };
});

// Delete
mcp.tool("deleteDocument", async ({ collection, filter }) => {
    const colName = validateCollection(collection);
    const result = await db.collection(colName).deleteMany(filter);
    return { deleted: result.deletedCount };
});

mcp.runTool = async (name, args) => {
    const tool = mcp._registeredTools[name];
    if (!tool) throw new Error(`Tool ${name} not found`);
    return await tool.callback(args);
};

console.log("MCP Server Ready");

// ----------------------------
// REST API for Streamlit
// ----------------------------

// Query
app.post("/tools/queryDocuments", async (req, res) => {
    try {
        const result = await mcp.runTool("queryDocuments", req.body);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Insert
app.post("/tools/insertDocument", async (req, res) => {
    try {
        res.json(await mcp.runTool("insertDocument", req.body));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update
app.post("/tools/updateDocument", async (req, res) => {
    try {
        res.json(await mcp.runTool("updateDocument", req.body));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete
app.post("/tools/deleteDocument", async (req, res) => {
    try {
        res.json(await mcp.runTool("deleteDocument", req.body));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start express
app.listen(3000, () =>
    console.log("REST API running at http://localhost:3000")
);
